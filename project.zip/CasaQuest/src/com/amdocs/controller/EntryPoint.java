package com.amdocs.controller;

import java.util.List;

import com.amdocs.casaquest.dao.PropertyServiceImpl;
import com.amdocs.casaquest.dao.PropertyServiceIntf;
import com.amdocs.casaquest.dao.SearchServiceImpl;
import com.amdocs.casaquest.dao.SearchServiceIntf;
import com.amdocs.casaquest.dao.UserServiceImpl;
import com.amdocs.casaquest.dao.UserServiceIntf;
import com.amdocs.casaquest.model.Property;
import com.amdocs.casaquest.model.User;

public class EntryPoint {

	public static void main(String[] args) {
		
		
		
		User user=new User();
		user.setEmail("Rahul");
		user.setName("rahul");
		user.setPhoneNumber("lsdjf");
		user.setUserType("Tenant");
		user.setPassword("12345");
		
		UserServiceIntf userinf= new UserServiceImpl();
		
		userinf.registerUser(user);
		
		userinf.loginUser("Rahul", "12345");
   
//		Property po=new Property("Esha empire", "rahul", "jarfile", 1, 1, "oooo", 1, "lsdj","pune","manjari");
//		
//		PropertyServiceIntf prop=new PropertyServiceImpl();
//		
//		prop.listProperty(po, 1);
//		
//		Property p= prop.getPropertiesByOwner(1, 1);
//		
//		p.toString();
//		
//		List<Property> demo= prop.getAllProperty();
//		
//		System.out.println(demo+" ");
//		
//		p.setDeposit(10000);
//		p.setStatus("Allotted");
//		p.setRent(2000);
//		prop.updateProperty(p);
//		
		SearchServiceIntf searchObj =new SearchServiceImpl();
		
		List<Property> properties=searchObj.searchPropertiesByLocation("pune", "manjari");
		
		System.out.println(properties+"");
		
	}

}
