package com.amdocs.controller;

//JDBC : Database connectivity with MySQL
//To connect with MySQL we need mysql-connector-java-8.0.23.jar
//To connect with oracle we need ojdbc8.jar

import java.sql.*;
import java.io.*;

public class TestClass {
	
	public static void main(String args[]) {
		String name = null;
		String password = null;
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		System.out.println("Enter name and passsword");
		try {
			name = br.readLine();
			password = br.readLine();
			//Class.forName("oracle.jdbc.driver.OracleDriver");
			Class.forName("com.mysql.cj.jdbc.Driver");
			//Connection con = DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "system", "AkhilesH123");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/questDb", "root", "root");
			Statement st = con.createStatement();

			int result = st.executeUpdate("Insert into emp values('" + name + "','" + password + "')");
			System.out.println("record inserted sucessfully");

			//int result = st.executeUpdate("delete from emp where name='"+name+"' and password='"+password+"'");
			//System.out.println("record deleted sucessfully");

			//int result = st.executeUpdate("update emp set name='RAM' where name='amdocs'");
			//System.out.println("record updated sucessfully");
			ResultSet rs = st.executeQuery("select * from emp");

			//JOptionPane.showMessageDialog(null,"record inserted successfully");
			System.out.println("Records are :");
			while (rs.next()) {
				System.out.println((rs.getString(1) + "  " + rs.getString(2)));
			}

		} catch (Exception e) {
			System.out.println("Sorry Connection Is Not Available" + e);
		}
	}
}