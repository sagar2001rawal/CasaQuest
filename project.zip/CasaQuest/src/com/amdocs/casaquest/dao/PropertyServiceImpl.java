package com.amdocs.casaquest.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.amdcos.casaquest.database.DatabaseService;
import com.amdocs.casaquest.model.Property;

public class PropertyServiceImpl implements PropertyServiceIntf {

	@Override
	public void listProperty(Property property, int ownerId) {
		try (Connection conn = DatabaseService.getConnection()) {

			// First, verify if the ownerId exists in the users table as an "Owner"
			String verifyOwnerSql = "SELECT * FROM users WHERE userId = ? AND userType = 'Owner'";
			PreparedStatement verifyOwnerStmt = conn.prepareStatement(verifyOwnerSql);
			verifyOwnerStmt.setInt(1, property.getOwnerId());
			ResultSet rs = verifyOwnerStmt.executeQuery();

			// If the owner doesn't exist, return an error
			if (!rs.next()) {
				System.out.println("Error: The ownerId does not exist or the user is not an owner.");
				return;
			}

			// If the owner exists, proceed to insert the property
			String sql = "INSERT INTO properties (name, type, address, rent, deposit, amenities, ownerId,city,colony) VALUES (?, ?, ?, ?, ?, ?, ?,?,?)";
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setString(1, property.getName());
			stmt.setString(2, property.getType());
			stmt.setString(3, property.getAddress());
			stmt.setDouble(4, property.getRent());
			stmt.setDouble(5, property.getDeposit());
			stmt.setString(6, property.getAmenities());
			stmt.setInt(7, property.getOwnerId());
			stmt.setString(8, property.getCity());
			stmt.setString(9, property.getColony());

			stmt.executeUpdate();
			System.out.println("Property added successfully!");
		} catch (Exception e) {
			System.out.println("Property not added" + e.getMessage());
		}
	}

	@Override
	public void updateProperty(Property property) {
		try (Connection conn = DatabaseService.getConnection()) {
			// First, check if the property with the given propertyId exists
			String checkPropertySql = "SELECT * FROM properties WHERE propertyId = ?";
			PreparedStatement checkPropertyStmt = conn.prepareStatement(checkPropertySql);
			checkPropertyStmt.setInt(1, property.getPropertyId());
			ResultSet rs = checkPropertyStmt.executeQuery();

			// If the property doesn't exist, return an error
			if (!rs.next()) {
				System.out.println("Error: The property with the given ID does not exist.");
				return;
			}

			// If the property exists, proceed to update the rent, deposit, and status
			String updateSql = "UPDATE properties SET rent = ?, deposit = ?, status = ? WHERE propertyId = ?";
			PreparedStatement updateStmt = conn.prepareStatement(updateSql);
			updateStmt.setDouble(1, property.getRent()); // Set new rent
			updateStmt.setDouble(2, property.getDeposit()); // Set new deposit
			updateStmt.setString(3, property.getStatus()); // Set new status (like 'available', 'allotted', etc.)
			updateStmt.setInt(4, property.getPropertyId()); // Set property ID as condition for update

			int rowsAffected = updateStmt.executeUpdate();
			if (rowsAffected > 0) {
				System.out.println("Property details updated successfully!");
			} else {
				System.out.println("Error: Property update failed.");
			}
		} catch (Exception e) {
			System.out.println("ERRORR while getting property");
		}

	}

	@Override
	public Property getPropertiesByOwner(int ownerId, int propertyId) {
		try (Connection conn = DatabaseService.getConnection()) {
			String sql = "SELECT * FROM properties WHERE propertyId = ?";
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setInt(1, propertyId);
			ResultSet rs = stmt.executeQuery();

			if (rs.next()) {
				return new Property(rs.getInt("propertyId"), rs.getString("name"), rs.getString("type"),
						rs.getString("address"), rs.getDouble("rent"), rs.getDouble("deposit"),
						rs.getString("amenities"), rs.getInt("ownerId"), rs.getString("status"),rs.getString("city"),rs.getNString("colony"));
			}
		} catch (Exception e) {
			System.out.println("ERRORR while getting property");
		}
		return null;

	}

	@Override
	public List<Property> getAllProperty() {
		List<Property> properties = new ArrayList<>();

		try (Connection conn = DatabaseService.getConnection()) {
			String sql = "SELECT * FROM properties";
			PreparedStatement stmt = conn.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				Property property = new Property(rs.getInt("propertyId"), rs.getString("name"), rs.getString("type"),
						rs.getString("address"), rs.getDouble("rent"), rs.getDouble("deposit"),
						rs.getString("amenities"), rs.getInt("ownerId"), rs.getString("status"),rs.getString("city"),rs.getNString("colony"));
				properties.add(property);
			}
		} catch (Exception e) {
			System.out.println("ERRORR while getting property");
		}

		return properties;
	}
}
