package com.amdocs.casaquest.dao;

import java.util.List;

import com.amdocs.casaquest.model.Property;

public interface SearchServiceIntf {
//	List<Property> searchProperties(String criteria);
//    List<Property> filterProperties(String location, double minRent, double maxRent);
    List<Property> searchPropertiesByLocation(String city, String colony);
}
