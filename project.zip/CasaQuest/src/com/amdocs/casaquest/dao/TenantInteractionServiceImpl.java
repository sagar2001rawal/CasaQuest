package com.amdocs.casaquest.dao;

public class TenantInteractionServiceImpl {

}
