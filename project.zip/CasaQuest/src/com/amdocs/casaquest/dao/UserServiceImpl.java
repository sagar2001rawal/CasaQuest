package com.amdocs.casaquest.dao;

import java.util.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amdcos.casaquest.database.DatabaseService;
import com.amdocs.casaquest.model.User;

public class UserServiceImpl implements UserServiceIntf {

	@Override
	public void logout(User user) {
		//
		String use="dsljf";
		return ;
		
	}

	@Override
	public void registerUser(User user)  {
		// TODO Auto-generated method stub
		String hashedPassword = hashPassword(user.getPassword());

		try (Connection conn = DatabaseService.getConnection()) {
			String sql = "INSERT INTO users (name, email, phoneNumber, password, userType) VALUES (?, ?, ?, ?, ?)";
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setString(1, user.getName());
			stmt.setString(2, user.getEmail());
			stmt.setString(3, user.getPhoneNumber());
			stmt.setString(4, hashedPassword);
			stmt.setString(5, user.getUserType());

			stmt.executeUpdate();
			System.out.println("User registered successfully!");
		}catch(SQLException e) {
			System.out.println("User  not register successfully!");
		}
	}

	@Override
	public User loginUser(String email, String password)  {
		// TODO Auto-generated method stub
		try (Connection conn = DatabaseService.getConnection()) {
			String sql = "SELECT * FROM users WHERE email = ?";
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setString(1, email);
			ResultSet rs = stmt.executeQuery();

			if (rs.next()) {
				String storedHashedPassword = rs.getString("password");
				if (hashPassword(password).equals(storedHashedPassword)) {
					System.out.println("Login successful!");
					int userId=Integer.parseInt(rs.getString("userId"));
					
					return new User(userId,rs.getString("name"), 
									rs.getString("email"),rs.getString("phoneNumber"),
									rs.getString("userType"));
				}
			}
			System.out.println("Invalid email or password");
		}catch(Exception e) {
			System.out.println("User  not register successfully!");
		}
		return null;
	}

	private String hashPassword(String password) {
		try {
			MessageDigest md = MessageDigest.getInstance("SHA-256");
			byte[] hash = md.digest(password.getBytes());
			StringBuilder sb = new StringBuilder();
			for (byte b : hash) {
				sb.append(String.format("%02x", b));
			}
			return sb.toString();
		} catch (NoSuchAlgorithmException e) {
			throw new RuntimeException("Error hashing password", e);
		}
	}
}
