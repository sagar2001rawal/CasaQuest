package com.amdocs.casaquest.dao;

import java.util.List;

import com.amdocs.casaquest.model.Property;

public interface PropertyServiceIntf {
	void listProperty(Property property, int ownerId);

	void updateProperty(Property property);

	 public List<Property> getAllProperty();

	Property getPropertiesByOwner(int ownerId, int propertyId);
}
