package com.amdocs.casaquest.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.amdcos.casaquest.database.DatabaseService;
import com.amdocs.casaquest.model.Property;

public class SearchServiceImpl implements SearchServiceIntf {

	@Override
    public List<Property> searchPropertiesByLocation(String city, String colony)  {
        List<Property> properties = new ArrayList<>();

        try (Connection conn = DatabaseService.getConnection()) {
            String sql = "SELECT * FROM properties WHERE city = ? AND colony = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, city);
            stmt.setString(2, colony);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Property property = new Property(
                    rs.getInt("propertyId"),
                    rs.getString("name"),
                    rs.getString("type"),
                    rs.getString("address"),
                    rs.getDouble("rent"),
                    rs.getDouble("deposit"),
                    rs.getString("amenities"),
                    rs.getInt("ownerId"),
                    rs.getString("status"),
                    rs.getString("city"),
                    rs.getString("colony")
                );
                properties.add(property);
            }
        }catch(Exception e)
        {
        	System.out.println("ERROR WHILE SEARCHING");
        }

        return properties;
    }
}


