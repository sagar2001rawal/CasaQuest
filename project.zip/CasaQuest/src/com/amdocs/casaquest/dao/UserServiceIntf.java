package com.amdocs.casaquest.dao;

import java.sql.SQLException;

import com.amdocs.casaquest.model.User;

public interface UserServiceIntf {
    
    void logout(User user);
    
    void registerUser(User user);
    
    User loginUser(String email, String password) ;
}

