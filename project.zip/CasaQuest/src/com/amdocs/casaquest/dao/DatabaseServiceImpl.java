package com.amdocs.casaquest.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import com.amdocs.casaquest.model.Property;
import com.amdocs.casaquest.model.User;
import java.sql.*;
import java.io.*;


public class DatabaseServiceImpl implements DatabaseServiceIntf {

	@Override
	public Statement connect() {
		// TODO Auto-generated method stub
		
	
		
		
		
	}

	@Override
	public void insertUser(User user) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void insertProperty(Property property) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateProperty(Property property) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public User getUser(String email) {
		// TODO Auto-generated method stub
		return null;
	}

	

	@Override
	public Property getProperty(int propertyId) {
		// TODO Auto-generated method stub
		return null;
	}

}
