package com.amdocs.casaquest.dao;

import java.sql.Statement;

import com.amdocs.casaquest.model.Property;
import com.amdocs.casaquest.model.User;

public interface DatabaseServiceIntf {
	    Statement connect();
	    void insertUser(User user);
	    void insertProperty(Property property);
	    void updateProperty(Property property);
	    User getUser(String email);
	    Property getProperty(int propertyId);
}
