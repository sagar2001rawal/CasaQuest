package com.amdocs.casaquest.dao;

public interface TenantInteractionIntf {
	void requestVisit(int tenantId, int propertyId);
    void rentProperty(int tenantId, int propertyId);
}
