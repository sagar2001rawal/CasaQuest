package com.amdocs.casaquest.model;

import java.util.*;


public class Owner extends User {
	
    public Owner(int userId, String name, String phoneNumber, String email, String password, String userType) {
		super(userId, name, phoneNumber, email, password, userType);
		// TODO Auto-generated constructor stub
	}
    
    public Owner(User user) {
    	
    	super(user.getUserId(),user.getName(),user.getPhoneNumber(),user.getEmail(),user.getPassword(),
    			user.getUserType());
    }

	private List<String> listedPropertyIds; // Properties owned by the owner

//    public void listProperty(Property property); // List a new property
//    public void updateProperty(Property property); // Update existing property
}