package com.amdocs.casaquest.model;
import java.util.*;

public class Property {
    private int propertyId;
    private String name;
    private String type;
    private String address;
    private double rent;
    private double deposit;
    private String amenities;
    private int ownerId;
    private String city;    // New field for city
    private String colony;  // New field for colony
    private String status;  // Available, Allotted
    private List<String> interestedTenantList;
	
    public Property(int propertyId, String name, String type, String address, double rent, double deposit,
			String amenities, int ownerId, String status, List<String> interestedTenantList) {
		super();
		this.propertyId = propertyId;
		this.name = name;
		this.type = type;
		this.address = address;
		this.rent = rent;
		this.deposit = deposit;
		this.amenities = amenities;
		this.ownerId = ownerId;
		this.status = status;
		this.interestedTenantList = interestedTenantList;
	}

    public Property(int propertyId, String name, String type, String address, double rent, double deposit,
			String amenities, int ownerId, String status,String city,String colony) {
    	super();
		this.propertyId = propertyId;
		this.name = name;
		this.type = type;
		this.address = address;
		this.rent = rent;
		this.deposit = deposit;
		this.amenities = amenities;
		this.ownerId = ownerId;
		this.status = status;
		this.city=city;
		this.colony=colony;
	
		
		
	}
    
    public Property( String name, String type, String address, double rent, double deposit,
			String amenities, int ownerId, String status,String city,String colony) {
    	super();
		this.propertyId = propertyId;
		this.name = name;
		this.type = type;
		this.address = address;
		this.rent = rent;
		this.deposit = deposit;
		this.amenities = amenities;
		this.ownerId = ownerId;
		this.status = status;
		this.city=city;
		this.colony=colony;
		
		
	}

	

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getColony() {
		return colony;
	}

	public void setColony(String colony) {
		this.colony = colony;
	}

	@Override
	public String toString() {
		return "Property [propertyId=" + propertyId + ", name=" + name + ", type=" + type + ", address=" + address
				+ ", rent=" + rent + ", deposit=" + deposit + ", amenities=" + amenities + ", ownerId=" + ownerId
				+ ", city=" + city + ", colony=" + colony + ", status=" + status + ", interestedTenantList="
				+ interestedTenantList + "]";
	}

	public int getPropertyId() {
		return propertyId;
	}

	public void setPropertyId(int propertyId) {
		this.propertyId = propertyId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public double getRent() {
		return rent;
	}

	public void setRent(double rent) {
		this.rent = rent;
	}

	public double getDeposit() {
		return deposit;
	}

	public void setDeposit(double deposit) {
		this.deposit = deposit;
	}

	public String getAmenities() {
		return amenities;
	}

	public void setAmenities(String amenities) {
		this.amenities = amenities;
	}

	public int getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(int ownerId) {
		this.ownerId = ownerId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<String> getInterestedTenantList() {
		return interestedTenantList;
	}

	public void setInterestedTenantList(List<String> interestedTenantList) {
		this.interestedTenantList = interestedTenantList;
	}


}