package com.amdocs.casaquest.model;

import java.util.List;

public class Tenant extends User {
	
	
    public Tenant(int userId, String name, String phoneNumber, String email, String password, String userType) {
		super(userId, name, phoneNumber, email, password, userType);
		// TODO Auto-generated constructor stub
	}
	private List<String> wishlistPropertyIds;
    private String rentedPropertyId;
     
}
